package C07ExceptionFileParsing.AuthorException;

import java.util.ArrayList;
import java.util.List;

public class AuthorRepository {
    List<Author> authorList;
    AuthorRepository(){
        authorList = new ArrayList<>();
    }

    void register(long id , String name, String email, String password){
        authorList.add(new Author(id, name, email, password));
    }

    void informationReturn(){
        for(Author au : authorList){
            System.out.println("이름 : " + au.getName());
            System.out.println("이메일 : " + au.getEmail());
        }
    }
}
